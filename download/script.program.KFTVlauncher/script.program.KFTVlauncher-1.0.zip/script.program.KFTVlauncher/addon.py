import xbmc

def launcher():
        xbmc.executebuiltin('XBMC.StartAndroidActivity("com.amazon.tv.launcher")')

launcher()
