import os
os.system("su -c 'reboot'")