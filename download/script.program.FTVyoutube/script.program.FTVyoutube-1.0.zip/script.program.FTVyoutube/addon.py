import xbmc

def launcher():
        xbmc.executebuiltin('XBMC.StartAndroidActivity("org.chromium.youtube_apk")')

launcher()