import xbmc

def launcher():
        xbmc.executebuiltin('XBMC.StartAndroidActivity("com.pandora.android.gtv")')

launcher()