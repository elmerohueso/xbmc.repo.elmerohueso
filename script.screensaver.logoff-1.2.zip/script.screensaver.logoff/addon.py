import xbmc
import os
import time

def logoff():
    '''# Logoff XBMC profile
    xbmc.executebuiltin("System.Logoff()")

		# If running Android, simulate Power button to sleep the device
		if xbmc.getCondVisibility("system.platform.android"):
		time.sleep(5)'''
	os.system('input keyevent "KEYCODE_POWER"')
        
logoff()
